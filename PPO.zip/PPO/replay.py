import time
import torch
import gym
import gym_super_mario_bros
from nes_py.wrappers import JoypadSpace
from gym.wrappers import FrameStack
from pathlib import Path
from wrappers import SkipFrame, GrayScaleObservation, ResizeObservation
from agent import PPOAgent

def play_game(checkpoint_path):
    # 1. Configurar Ambiente
    if gym.__version__ < '0.26':
        env = gym_super_mario_bros.make("SuperMarioBros-1-1-v0", new_step_api=True)
    else:
        env = gym_super_mario_bros.make("SuperMarioBros-1-1-v0", render_mode='human', apply_api_compatibility=True)

    env = JoypadSpace(env, [["right"], ["right", "A"]])
    env = SkipFrame(env, skip=4)
    env = GrayScaleObservation(env)
    env = ResizeObservation(env, shape=84)
    if gym.__version__ < '0.26':
        env = FrameStack(env, num_stack=4, new_step_api=True)
    else:
        env = FrameStack(env, num_stack=4)

    # 2. Inicializar Agente
    mario = PPOAgent(state_dim=(4, 84, 84), action_dim=env.action_space.n, save_dir=Path("."))

    # 3. Carregar Modelo
    print(f"Carregando PPO: {checkpoint_path}")
    checkpoint = torch.load(checkpoint_path, map_location=mario.device)
    if 'model' in checkpoint:
        mario.policy.load_state_dict(checkpoint['model'])
    else:
        mario.policy.load_state_dict(checkpoint)

    mario.policy.eval()

    state = env.reset()
    total_reward = 0

    while True:
        env.render()

        # Act determinístico ou estocástico?
        # Para avaliação PPO, geralmente queremos a ação com maior probabilidade (determinístico)
        # Mas o método act original faz sample. Vamos adaptar ligeiramente aqui:
        state_tensor = torch.tensor(state[0].__array__(), device=mario.device).unsqueeze(0)
        with torch.no_grad():
            dist, _ = mario.policy(state_tensor)
            # Para replay: argmax das probabilidades em vez de sample
            action = torch.argmax(dist.probs).item()

        next_state, reward, done, _, info = env.step(action)
        total_reward += reward
        state = next_state

        time.sleep(0.05)

        if done or info.get("flag_get", False):
            print(f"Fim! Reward: {total_reward}")
            break

if __name__ == "__main__":
    # Ajuste o caminho conforme necessário
    checkpoint_dir = Path("checkpoints_ppo")
    try:
        latest = max(checkpoint_dir.glob("**/*.chkpt"), key=lambda p: p.stat().st_mtime)
        play_game(latest)
    except Exception as e:
        print(f"Erro: {e}. Verifique se existe a pasta checkpoints_ppo e ficheiros .chkpt")